import processing.core.PApplet;

public class Sketch extends PApplet {

  public void settings() {
    // size of the image
    size(400, 400);
  }

  public void setup() {
    // background colour
    background(84,175,255);
}

  public void draw() {
    // stem
    fill(53,136,86);
    rect(195,200,8,200); 
    // upper leaf
    fill(53,136,86);
    ellipse(224,300,40,10); 
    // lower leaf
    fill(53,136,86);
    ellipse(174,325,40,10); 
    
    // flower center
    fill(255,242,0);
    ellipse(200,200,50,50);
    // left petal
    fill(255,0,0);
    ellipse(150,200,50,50);
    // right petal
    fill(255,0,0);
    ellipse(250,200,50,50);
    // upper right petal
    fill(255,0,0);
    ellipse(225,155,50,50);
    // upper left petal
    fill(255,0,0);
    ellipse(175,155,50,50);
    // lower right petal
    fill(255,0,0);
    ellipse(225,245,50,50);
    // lower left petal
    fill(255,0,0);
    ellipse(175,245,50,50);
  }
}