void setup() {
  size(400,400);
  background(0,0,255);
}

void draw() {
  line(200,0,200,0);
  fill(138,153,245);
  ellipse(200,200,100,100);
  ellipse(50,200,50,50);
  ellipse(150,200,50,50);
  ellipse(200,50,50,50);
  ellipse(200,150,50,50);
}